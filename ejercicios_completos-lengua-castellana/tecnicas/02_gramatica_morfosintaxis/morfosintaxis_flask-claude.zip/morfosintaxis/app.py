from flask import Flask, render_template, jsonify, request, session
import json, os, random

app = Flask(__name__)
app.secret_key = 'morfosintaxis-bilingual-2024'

DATA_PATH = os.path.join(os.path.dirname(__file__), 'static', 'data', 'data.json')

def load_data():
    with open(DATA_PATH, encoding='utf-8') as f:
        return json.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/data')
def get_data():
    return jsonify(load_data())

@app.route('/api/progress', methods=['GET'])
def get_progress():
    return jsonify(session.get('progress', {
        'ejercicios_completados': [],
        'ejercicios_correctos': [],
        'flashcards_vistas': [],
        'puntaje_total': 0,
        'racha': 0,
        'max_racha': 0,
        'medallas': []
    }))

@app.route('/api/progress', methods=['POST'])
def save_progress():
    data = request.json
    session['progress'] = data
    session.modified = True
    return jsonify({'ok': True})

@app.route('/api/reset', methods=['POST'])
def reset_progress():
    session['progress'] = {
        'ejercicios_completados': [],
        'ejercicios_correctos': [],
        'flashcards_vistas': [],
        'puntaje_total': 0,
        'racha': 0,
        'max_racha': 0,
        'medallas': []
    }
    session.modified = True
    return jsonify({'ok': True})

if __name__ == '__main__':
    app.run(debug=True, port=5050)
